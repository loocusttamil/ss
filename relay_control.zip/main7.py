from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.graphics import Color, Rectangle
import requests

SERVER_URL = "http://127.0.0.1:8000/api/"  # Replace with your Django server URL

# Custom BoxLayout with light black background color
class CustomBoxLayout(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(0.1, 0.1, 0.1, 1)  # Light black in RGBA
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self.update_rect, pos=self.update_rect)

    def update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos


class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = CustomBoxLayout(orientation="vertical", padding=20, spacing=15)

        # Title
        self.layout.add_widget(Label(text="Login", font_size=56, size_hint=(1, 0.15)))

        # Username input
        self.username_input = TextInput(
            hint_text="Username",
            multiline=False,
            size_hint=(1, 0.05),  # Reduced size
            font_size=36,
        )
        self.layout.add_widget(self.username_input)

        # Password input
        self.password_input = TextInput(
            hint_text="Password",
            multiline=False,
            password=True,
            size_hint=(1, 0.05),  # Reduced size
            font_size=36,
        )
        self.layout.add_widget(self.password_input)

        # Login Button
        self.login_button = Button(
            text="Login",
            size_hint=(1, 0.04),  # Decreased size
            background_color=(0.0, 0.4, 0.8, 1),  # Dark sky blue
            font_size=36,
        )
        self.login_button.bind(on_press=self.login)
        self.layout.add_widget(self.login_button)

        # Error Label
        self.error_label = Label(
            text="", color=(1, 0, 0, 1), size_hint=(1, 0.08), font_size=32
        )
        self.layout.add_widget(self.error_label)

        self.add_widget(self.layout)

    def login(self, instance):
        username = self.username_input.text
        password = self.password_input.text
        if not username or not password:
            self.error_label.text = "Please fill in all fields."
            return
        response = requests.post(f"{SERVER_URL}login/", json={"username": username, "password": password})
        if response.status_code == 200:
            app = App.get_running_app()
            app.token = response.json().get("token")
            app.screen_manager.current = "home"
        else:
            self.error_label.text = "Invalid credentials. Try again."


class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = CustomBoxLayout(orientation="vertical", padding=10, spacing=15)

        # Navigation Bar
        nav_bar = CustomBoxLayout(orientation="horizontal", size_hint=(1, 0.1), padding=5, spacing=10)
        home_button = Button(text="Home", size_hint=(0.3, 1), background_color=(0.0, 0.4, 0.8, 1), font_size=32)
        home_button.disabled = True
        settings_button = Button(text="Settings", size_hint=(0.3, 1), background_color=(0.0, 0.4, 0.8, 1), font_size=32)
        settings_button.bind(on_press=self.go_to_settings)
        logout_button = Button(text="Logout", size_hint=(0.2, 1), background_color=(1, 0, 0, 1), font_size=32)
        logout_button.bind(on_press=self.logout)
        nav_bar.add_widget(home_button)
        nav_bar.add_widget(settings_button)
        nav_bar.add_widget(logout_button)
        self.layout.add_widget(nav_bar)

        # Relay Controls
        self.relay_buttons = []
        for i in range(4):
            relay_box = CustomBoxLayout(orientation="horizontal", size_hint=(1, 0.2), spacing=15)
            btn = RelayButton(relay_id=i + 1)
            btn.size_hint = (0.25, 1)  # Decreased size
            btn.font_size = 32
            status_label = Label(text="OFF", size_hint=(0.3, 1), color=(1, 0, 0, 1), font_size=60)
            btn.status_label = status_label
            relay_box.add_widget(btn)
            relay_box.add_widget(status_label)
            self.layout.add_widget(relay_box)
            self.relay_buttons.append(btn)

        # Refresh Button
        refresh_btn = Button(text="Refresh", size_hint=(1, 0.08), background_color=(0.0, 0.4, 0.8, 1), font_size=36)
        refresh_btn.bind(on_press=self.refresh_status)
        self.layout.add_widget(refresh_btn)

        self.add_widget(self.layout)

    def refresh_status(self, instance):
        app = App.get_running_app()
        headers = {"Authorization": f"Bearer {app.token}"}
        response = requests.get(f"{SERVER_URL}relay/", headers=headers)
        if response.status_code == 200:
            data = response.json()
            for relay in data:
                self.relay_buttons[relay["relay_id"] - 1].update_status(relay["status"])

    def logout(self, instance):
        app = App.get_running_app()
        app.token = None
        app.screen_manager.current = "login"

    def go_to_settings(self, instance):
        app = App.get_running_app()
        app.screen_manager.current = "settings"


class RelayButton(Button):
    def __init__(self, relay_id, **kwargs):
        super().__init__(**kwargs)
        self.relay_id = relay_id
        self.status = False
        self.text = f"Relay {relay_id}"
        self.font_size = 32
        self.background_color = (0.0, 0.4, 0.8, 1)
        self.status_label = None
        self.bind(on_press=self.toggle_relay)

    def toggle_relay(self, instance):
        app = App.get_running_app()
        headers = {"Authorization": f"Bearer {app.token}"}
        self.status = not self.status
        requests.post(
            f"{SERVER_URL}relay/",
            json={"relay_id": self.relay_id, "status": self.status},
            headers=headers,
        )
        self.update_status(self.status)

    def update_status(self, status):
        self.status = status
        if self.status:
            self.status_label.text = "ON"
            self.status_label.color = (0, 1, 0, 1)
        else:
            self.status_label.text = "OFF"
            self.status_label.color = (1, 0, 0, 1)


class RelayControlApp(App):
    def build(self):
        # Default Kivy logo is used (no need to set self.icon)
        self.token = None
        self.screen_manager = ScreenManager()
        self.screen_manager.add_widget(LoginScreen(name="login"))
        self.screen_manager.add_widget(HomeScreen(name="home"))
        return self.screen_manager


if __name__ == "__main__":
    RelayControlApp().run()